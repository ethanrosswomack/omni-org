# Pi SDK Integration Notes

- Register on Pi Developer Portal
- Setup sandbox
- Integrate Pi SDK in `connect.astro`
